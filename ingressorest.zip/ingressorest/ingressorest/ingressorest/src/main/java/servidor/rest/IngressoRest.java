package servidor.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;

import servidor.negocio.Ingresso;

@Path("/ingresso")
public class IngressoRest {
	@GET
	@Produces("application/json")
	public Response consultaSensores() throws
	JSONException {
	//gerando objetos de dados de teste
		Ingresso s1 = new Ingresso();
	s1.setNome("Guilherme");
	s1.setEmail("guilherme.p2022@aluno.ifsc.edu.br");
	s1.setData("12/09/2022");
	s1.setSetor((byte)0);
	s1.setTipoingresso((byte)0);
	
	
	//gerando JSON com os dados de teste
	JSONArray json = new JSONArray();
	json.put(s1.toJsonObject());
	String result = json.toString();
	System.out.println(result);
	return
	Response.status(200).entity(result).build();
	}
	@POST
	@Produces("application/json")
	@Consumes("application/json")
	public Response cadastraSensor(String json) throws
	JSONException {
	System.out.println("parametro recebido = "
	+json);
	int statusCadastro = 200;
	return Response.status( statusCadastro
	).entity(json).build();
	}
	}


