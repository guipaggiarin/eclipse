package servidor.negocio;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONException;
import org.json.JSONObject;

public class Ingresso {
	//atributos
    private String nome;
    private String email;
    private String data;
    private byte setor;
    private byte tipoingresso;

    //m�todos
    public String getNome() {return nome;}
    public void setNome(String nome) {this.nome = nome;}
    public String getEmail() {return email;}
    public void setEmail(String email) {this.email = email;}
    public String getData() {return data;}
    public void setData(String strdata) {
        SimpleDateFormat formato =
                new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date data = (Date) formato.parse(strdata);
            //se chegar at� aqui n�o deu erro no parser
            this.data = strdata;
            } catch (ParseException e)
            {
            this.data = "";
            }
    }

    public byte getSetor() { return setor;}
    public void setSetor(byte setor) {this.setor = setor;}
    public byte getTipoingresso() { return tipoingresso;}
    public void setTipoingresso(byte tipoingresso) {this.tipoingresso = tipoingresso;}


    //construtor
public Ingresso (JSONObject jp) {
    try {
        this.setNome((String) jp.get("nome"));
        this.setEmail((String) jp.get("email"));
        this.setData((String) jp.get("dataingresso"));
        Byte codigo = (byte) jp.get("setor");
        this.setSetor(codigo);
        codigo = (byte) jp.get("tipoingresso");
        this.setTipoingresso(codigo);
    } catch (JSONException e) {
        e.printStackTrace();
    }
}

    //CONSTRUTOR - Inicializa os atributos para gerar Objeto Json
    public Ingresso () {
        this.setNome("");
        this.setEmail("");
        this.setData("");
        this.setSetor((byte)0);
        this.setTipoingresso((byte)0);

    }

    //Metodo retorna o objeto com dados no formato JSON
    public JSONObject toJsonObject() {
        JSONObject json = new JSONObject();
        try {
            json.put("nome", this.nome);
            json.put("email", this.email);
            json.put("dataingresso", this.data);
            json.put("setor", this.setor);
            json.put("tipoingresso", this.tipoingresso);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }


}
