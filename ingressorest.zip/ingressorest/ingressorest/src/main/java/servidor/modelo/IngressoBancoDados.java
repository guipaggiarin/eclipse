package servidor.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import servidor.negocio.Ingresso;

public class IngressoBancoDados {

	public boolean inserir(Ingresso ingresso) throws Exception {
			  boolean retorno = false;
			  //comentario
			  PreparedStatement stmt = null;
			  Connection con = null;
			  String sql =  "insert into Ingresso(nmNome, nmEmail, dtData, tpIngresso, tpSetor) values (?, ?, ?, ?, ?)";
			  try {
			    con = UtilJDBC.getConnection();
			    stmt = con.prepareStatement(sql);
			    stmt.setString(1, ingresso.getNome());
			    stmt.setString(2, ingresso.getEmail()); 
			    //stmt.setDate(3, ingresso.getData()); 
			    stmt.setInt(4, ingresso.getTipoingresso()); 
			    stmt.setInt(5, ingresso.getSetor()); 
			    stmt.executeUpdate();
			    retorno = true;
			  } catch (Exception e ) {
			    System.out.println(e);
			  } finally {
			    if (stmt != null) { stmt.close(); } 
			    if (con != null) { con.close();}
			  } 
			  return retorno; }
			    
}
