package servidor.modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;

import servidor.negocio.Ingresso;

public class IngressoBancoDados {

	public boolean inserir(Ingresso ingresso) throws Exception {
			  boolean retorno = false;
			  //comentario
			  PreparedStatement stmt = null;
			  Connection con = null;
			  String sql =  "insert into Ingresso(nmNome, nmEmail, dtData, tpIngresso, tpSetor) values (?, ?, ?, ?, ?)";
			  try {
			    con = UtilJDBC.getConnection();
			    stmt = con.prepareStatement(sql);
			    stmt.setString(1, ingresso.getNome());
			    stmt.setString(2, ingresso.getEmail()); 
			   
			    DateFormat formato = new SimpleDateFormat("dd-MM-yyyy");
			    Date data = (Date) formato.parse(ingresso.getData());
			    Instant instant = data.toInstant();
			    ZoneId zoneId = ZoneId.of ( "America/Sao_Paulo" );
			    ZonedDateTime zdt = ZonedDateTime.ofInstant ( instant , zoneId );
			    LocalDate dataBD = zdt.toLocalDate();
			       stmt.setObject(3, dataBD);
			    stmt.setInt(4, ingresso.getTipoingresso()); 
			    stmt.setInt(5, ingresso.getSetor()); 
			    stmt.executeUpdate();
			    retorno = true;
			  } catch (Exception e ) {
			    System.out.println(e);
			  } finally {
			    if (stmt != null) { stmt.close(); } 
			    if (con != null) { con.close();}
			  } 
			  return retorno; }
	//parte 1 de 2
	public ArrayList<Ingresso> consultarPorNome (String
	strNomePesquisa) throws Exception {
	ArrayList<Ingresso> usuarios =
	new ArrayList<Ingresso>();
	Ingresso ing = null;
	PreparedStatement stmt = null;
	Connection con = null;
	String sql ="select nmNome, nmEmail"
	+ ",dtData, tpIngresso, tpSetor from Usuario "
	+ "where upper(nmNome) like ?";
	 try {
	 con = UtilJDBC.getConnection();
	 stmt = con.prepareStatement(sql);
	 stmt.setString(1, "%"+
	 strNomePesquisa.toUpperCase()+"%");
	 ResultSet rs = stmt.executeQuery();
	 while(rs.next()) {
	 ing = new Ingresso();
	 ing.setNome(rs.getString("nmNome"));
	 ing.setEmail(rs.getString("nmEmail"));
	 ing.setData(rs.getString("dtData"));
	 ing.setTipoingresso(rs.getInt("tpIngresso"));
	 ing.setSetor(rs.getInt("tpSetor"));
	 //adiciona objeto no arraylist
	 usuarios.add(ing);
	 }
	 } catch (Exception e ) {
	 System.out.println(e);
	 } finally {
	 if (stmt != null) { stmt.close(); }
	 if (con != null) { con.close();}
	 }
	 return usuarios;
	}

			    
}
