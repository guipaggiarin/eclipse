package servidor.modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class UtilJDBC {
	static final String url =
			//jdbc:banco:ip_servidor:porta/database    
			"jdbc:postgresql://127.0.0.1:5432/buytheticket";
			   static final String nome = "seg";
			   static final String email = "seg";
			   public static Connection getConnection() throws Exception{
				   Connection con = null;
				   try { 
				     Class.forName("org.postgresql.Driver");
				     System.out.println("JDBC Driver Ok");
				     con = DriverManager.getConnection(url,nome,email);  
				     if (con != null) {
				         System.out.println("Conex�o Ok");
				         return con;
				     } else {
				         throw new Exception("A conex�o n�o foi criada!"); 
				     }
				   } catch (ClassNotFoundException e) {
				       System.out.println("Driver JDBC inv�lido");
				       e.printStackTrace();
				   } catch (SQLException e) {
				       System.out.println("Falha na conex�o");
				       e.printStackTrace();
				   }
				   return con;
				 }			
			  
}